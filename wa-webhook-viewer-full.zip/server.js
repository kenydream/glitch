
const express    = require('express');
const bodyParser = require('body-parser');
const path       = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// simple in‑memory ring buffer (latest 500)
const logs = [];

app.use(bodyParser.json());

/* Webhook verification */
app.get('/webhook', (req, res) => {
  const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
  const { 'hub.mode': mode, 'hub.verify_token': token, 'hub.challenge': challenge } = req.query;

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('✅ Webhook verified!');
    return res.status(200).send(challenge);
  }
  res.sendStatus(403);
});

/* Incoming WhatsApp events */
app.post('/webhook', (req, res) => {
  if (req.body && req.body.object === 'whatsapp_business_account') {
    console.log('📩 Incoming webhook:');
    console.dir(req.body, { depth: null });

    // extract a short summary for the viewer
    let msg = {};
    try {
      if (req.body.entry && req.body.entry[0] &&
          req.body.entry[0].changes && req.body.entry[0].changes[0] &&
          req.body.entry[0].changes[0].value &&
          req.body.entry[0].changes[0].value.messages &&
          req.body.entry[0].changes[0].value.messages[0]) {
        msg = req.body.entry[0].changes[0].value.messages[0];
      }
    } catch (_) {}

    logs.push({
      ts:   new Date().toISOString(),
      from: msg.from || '—',
      body: (msg.text && msg.text.body) ? msg.text.body
            : JSON.stringify(msg).slice(0, 120)
    });
    if (logs.length > 500) logs.shift(); // cap buffer

    return res.sendStatus(200);
  }
  res.sendStatus(404);
});

/* JSON feed for viewer */
app.get('/api/logs', (_req, res) => res.json(logs.slice().reverse()));

/* Serve static viewer */
app.use(express.static(path.join(__dirname, 'public')));

/* Fallback text */
app.get('/', (_req, res) => res.send('🚀 WhatsApp Webhook is running!'));

app.listen(PORT, () => console.log(`🚀 Server listening on ${PORT}`));
